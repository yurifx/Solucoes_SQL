If  Exists (Select Name
            From   sysobjects
            Where  Name = 'InspAvaria_Lst' and type = 'P')
    Drop Procedure dbo.InspAvaria_Lst
GO

Create Procedure dbo.InspAvaria_Lst
----------------------------------------------------------------------------------------------------
-- Lista as avarias de um veículo (InspVeiculo_ID)
----------------------------------------------------------------------------------------------------
(
@p_InspVeiculo_ID Int
)
AS

SET NOCOUNT ON

Select av.InspAvaria_ID,
       av.InspVeiculo_ID,
       av.AvArea_ID,
       av.AvDano_ID,
       av.AvSeveridade_ID,
       av.AvQuadrante_ID,
       av.AvGravidade_ID,
       av.AvCondicao_ID,
       av.FabricaTransporte,

       a.Codigo    as AreaCodigo,
       a.Nome_Pt   as Area_Pt,
       a.Nome_En   as Area_En,
       a.Nome_Es   as Area_Es,

       d.Codigo    as DanoCodigo,
       d.Nome_Pt   as Dano_Pt,
       d.Nome_En   as Dano_En,
       d.Nome_Es   as Dano_Es,

       s.Codigo    as SevCodigo,
       s.Nome_Pt   as Severidade_Pt,
       s.Nome_En   as Severidade_En,
       s.Nome_Es   as Severidade_Es,

       q.Codigo    as QuadranteCodigo,
       q.Nome_Pt   as Quadrante_Pt,
       q.Nome_En   as Quadrante_En,
       q.Nome_Es   as Quadrante_Es,

       c.Codigo    as CondicaoCodigo,
       c.Nome_Pt   as Condicao_Pt,
       c.Nome_En   as Condicao_En,
       c.Nome_Es   as Condicao_Es

From       InspAvaria  av
Inner Join AvArea       a on av.AvArea_ID       = a.AvArea_ID
Inner Join AvDano       d on av.AvDano_ID       = d.AvDano_ID
Inner Join AvSeveridade s on av.AvSeveridade_ID = s.AvSeveridade_ID
Inner Join AvQuadrante  q on av.AvQuadrante_ID  = q.AvQuadrante_ID
Inner Join AvCondicao   c on av.AvCondicao_ID   = c.AvCondicao_ID

Where InspVeiculo_ID = @p_InspVeiculo_ID

GO

/*
EXEC InspAvaria_Lst @p_InspVeiculo_ID = 1
*/

-- FIM